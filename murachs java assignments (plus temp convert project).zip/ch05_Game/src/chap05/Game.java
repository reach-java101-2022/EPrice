/**
 * @author Holly Norton
 * @date Mar 12, 2023
 * @filename Game.java
 */
package chap05;

import java.util.Scanner;

public class Game {

	public static void main(String[] args) {
		// declare a variable to hold user guess count, and set it to 0
		int numOfGuesses = 0;
		GameHelper helper = new GameHelper();

		// make a Simple Startup project
		SimpleDotCom theDotCom = new SimpleDotCom();
		// compute a random number between 0 and 4
		int randomNum = (int) (Math.random() * 5);
		// make an int array with the 3 cell locations

		int[] locations = { randomNum, randomNum + 1, randomNum + 2 };
		// invoke setLocationCells on the Startup object
		theDotCom.setLocationCells(locations);
		// declare a boolean isAlive
		boolean isAlive = true;
		while (isAlive == true) {
			// while the startup is still alive
			String guess = helper.getUserInput("enter a number");
			// get user input
			String result = theDotCom.checkYourself(guess);
			// invoke checkYourself() on Startup
			numOfGuesses++;
			// increment numOfGuesses
			if (result.equals("kill")) {
				// if result is "kill"
				isAlive = false;
				// set isAlive to false
				System.out.println("You took " + numOfGuesses + " guesses");
				// print the number of user guesses
			}
		}
	}
}
