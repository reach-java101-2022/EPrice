/**
 * @author Holly Norton
 * @date Mar 12, 2023
 * @filename SimpleDotCom.java
 */
package chap05;

public class SimpleDotCom {
	int[] locationCells;
	int numOfHits = 0;

	public void setLocationCells(int[] locs) {
		locationCells = locs;
	}

	public String checkYourself(String stringGuess) {
		// get the user guess
		int guess = Integer.parseInt(stringGuess);
		String result = "miss";
		for (int cell : locationCells) {
			// repeat with each cell in the int array
			if (guess == cell) {
				// if the user guess matches
				result = "hit";
				numOfHits++;
				// increment the number of hits
				break;
			
			} // end if
		}  // end for
		
		if (numOfHits == locationCells.length) {
			// if number of hits is 3
			result = "kill";
			// return "kill" as the result
		} // end if
		
		System.out.println(result);
		// return "hit"
		return result;
		// return "miss"
	}  // end method
}
