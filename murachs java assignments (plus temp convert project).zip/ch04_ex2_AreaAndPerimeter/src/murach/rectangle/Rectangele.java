/**
 * @author Emma Price
 * @date Feb 14, 2023
 *@filename Rectangele.java
 */
package murach.rectangle;

public class Rectangele {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
